This folder is required by app.json (icon.png, splash.png, adaptive-icon.png, favicon.png).

The original project is missing these files, so placeholder images were created to allow Expo to bundle.
Replace these placeholders with your real app icons/splash screens before releasing.

