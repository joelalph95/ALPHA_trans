import AsyncStorage from '@react-native-async-storage/async-storage';

// 🔧 CHANGER CETTE URL PAR L'IP DE VOTRE SERVEUR
// Exemple: 'http://192.168.1.100:5000'  (IP locale de votre PC)
// Pour Android Emulator: 'http://10.0.2.2:5000'
export const API_BASE_URL = 'http://10.232.178.231:5000';

const getToken = async () => {
  return await AsyncStorage.getItem('token');
};

const request = async (method, endpoint, body = null, requireAuth = true) => {
  const headers = { 'Content-Type': 'application/json' };

  if (requireAuth) {
    const token = await getToken();
    if (token) headers['Authorization'] = `Bearer ${token}`;
  }

  const options = { method, headers };
  if (body) options.body = JSON.stringify(body);

  try {
    const response = await fetch(`${API_BASE_URL}/api${endpoint}`, options);
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || 'Erreur serveur');
    return data;
  } catch (err) {
    throw err;
  }
};

// Auth
export const login = (email, mot_de_passe) =>
  request('POST', '/auth/login', { email, mot_de_passe }, false);

export const register = (nom, email, mot_de_passe, role, telephone) =>
  request('POST', '/auth/register', { nom, email, mot_de_passe, role, telephone }, false);

export const getProfile = () => request('GET', '/auth/profile');

// Villes
export const getVilles = () => request('GET', '/villes');

// Demandes (Passager)
export const createDemande = (ville_depart_id, ville_arrivee_id) =>
  request('POST', '/demandes', { ville_depart_id, ville_arrivee_id });

export const getMesDemandes = () => request('GET', '/demandes/mes-demandes');

// Demandes (Chauffeur/Admin)
export const getAllDemandes = () => request('GET', '/demandes');

export const accepterDemande = (id) => request('PATCH', `/demandes/${id}/accepter`);
export const refuserDemande = (id) => request('PATCH', `/demandes/${id}/refuser`);

// Réservations
export const getReservations = () => request('GET', '/reservations');

// Plannings
export const getPlannings = () => request('GET', '/plannings');
