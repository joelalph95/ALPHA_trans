import React, { useState, useEffect } from 'react';
import {
  View, Text, StyleSheet, FlatList,
  TouchableOpacity, RefreshControl, ActivityIndicator, Alert,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { getAllDemandes, accepterDemande, refuserDemande } from '../api/client';
import { COLORS, FONTS, SPACING, RADIUS, SHADOW } from '../utils/theme';

export default function MesPassagersScreen({ navigation }) {
  const [demandes, setDemandes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [actionLoading, setActionLoading] = useState(null);

  const fetchDemandes = async () => {
    try {
      const data = await getAllDemandes();
      setDemandes(data);
    } catch (e) {
      Alert.alert('Erreur', e.message);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => { fetchDemandes(); }, []);

  const handleAction = async (id, action) => {
    setActionLoading(id + action);
    try {
      if (action === 'accepter') await accepterDemande(id);
      else await refuserDemande(id);
      Alert.alert('✅', action === 'accepter' ? 'Demande acceptée !' : 'Demande refusée.');
      fetchDemandes();
    } catch (e) {
      Alert.alert('Erreur', e.message);
    } finally {
      setActionLoading(null);
    }
  };

  const renderItem = ({ item }) => {
    const date = new Date(item.date_demande);
    const dateStr = date.toLocaleDateString('fr-FR', { day: 'numeric', month: 'short' });
    const timeStr = date.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });

    return (
      <View style={styles.card}>
        {/* Passager info */}
        <View style={styles.cardHeader}>
          <View style={styles.passagerAvatar}>
            <Text style={styles.passagerAvatarLetter}>{item.passager?.charAt(0)?.toUpperCase()}</Text>
          </View>
          <View style={{ flex: 1 }}>
            <Text style={styles.passagerName}>{item.passager}</Text>
            <Text style={styles.cardDateTime}>{dateStr} à {timeStr}</Text>
          </View>
          <View style={styles.pendingBadge}>
            <View style={styles.pendingDot} />
            <Text style={styles.pendingText}>En attente</Text>
          </View>
        </View>

        {/* Route */}
        <View style={styles.route}>
          <RoutePoint color={COLORS.primary} icon="location" label="Départ" city={item.ville_depart} />
          <View style={styles.routeMid}>
            <View style={styles.dottedLine} />
            <Ionicons name="bus" size={16} color={COLORS.primaryLight} />
            <View style={styles.dottedLine} />
          </View>
          <RoutePoint color={COLORS.accent} icon="flag" label="Arrivée" city={item.ville_arrivee} />
        </View>

        {/* Actions */}
        <View style={styles.actions}>
          <TouchableOpacity
            style={styles.refuserBtn}
            onPress={() => handleAction(item.id, 'refuser')}
            disabled={!!actionLoading}
          >
            {actionLoading === item.id + 'refuser' ? (
              <ActivityIndicator color={COLORS.error} size="small" />
            ) : (
              <>
                <Ionicons name="close" size={16} color={COLORS.error} />
                <Text style={styles.refuserText}>Refuser</Text>
              </>
            )}
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.accepterBtn}
            onPress={() => handleAction(item.id, 'accepter')}
            disabled={!!actionLoading}
          >
            <LinearGradient
              colors={[COLORS.primary, '#2D6A4F']}
              style={styles.accepterGradient}
              start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}
            >
              {actionLoading === item.id + 'accepter' ? (
                <ActivityIndicator color="#fff" size="small" />
              ) : (
                <>
                  <Ionicons name="checkmark" size={16} color="#fff" />
                  <Text style={styles.accepterText}>Accepter</Text>
                </>
              )}
            </LinearGradient>
          </TouchableOpacity>
        </View>
      </View>
    );
  };

  return (
    <View style={styles.container}>
      <LinearGradient colors={['#0B2447', '#19376D']} style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
          <Ionicons name="arrow-back" size={22} color="#fff" />
        </TouchableOpacity>
        <View>
          <Text style={styles.headerTitle}>Mes Passagers</Text>
          <Text style={styles.headerSub}>{demandes.length} demande(s) en attente</Text>
        </View>
      </LinearGradient>

      {loading ? (
        <ActivityIndicator style={{ marginTop: 40 }} color={COLORS.primary} size="large" />
      ) : (
        <FlatList
          data={demandes}
          keyExtractor={item => item.id.toString()}
          renderItem={renderItem}
          contentContainerStyle={styles.list}
          refreshControl={
            <RefreshControl refreshing={refreshing} onRefresh={() => { setRefreshing(true); fetchDemandes(); }} tintColor={COLORS.primary} />
          }
          ListEmptyComponent={
            <View style={styles.empty}>
              <Ionicons name="people-outline" size={56} color={COLORS.border} />
              <Text style={styles.emptyTitle}>Aucune demande</Text>
              <Text style={styles.emptySub}>Aucun passager en attente pour le moment</Text>
            </View>
          }
        />
      )}
    </View>
  );
}

const RoutePoint = ({ color, icon, label, city }) => (
  <View style={styles.routePoint}>
    <View style={[styles.routeIconWrapper, { backgroundColor: `${color}15` }]}>
      <Ionicons name={icon} size={16} color={color} />
    </View>
    <Text style={styles.routeLabel}>{label}</Text>
    <Text style={styles.routeCity}>{city}</Text>
  </View>
);

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.background },

  header: {
    flexDirection: 'row', alignItems: 'center', gap: SPACING.md,
    paddingTop: 55, paddingBottom: SPACING.lg, paddingHorizontal: SPACING.lg,
  },
  backBtn: {
    width: 38, height: 38, borderRadius: 19,
    backgroundColor: 'rgba(255,255,255,0.15)',
    justifyContent: 'center', alignItems: 'center',
  },
  headerTitle: { fontSize: FONTS.xl, fontWeight: '800', color: '#fff' },
  headerSub: { fontSize: FONTS.sm, color: 'rgba(255,255,255,0.7)' },

  list: { padding: SPACING.lg, gap: SPACING.md },

  card: {
    backgroundColor: COLORS.card, borderRadius: RADIUS.xl,
    overflow: 'hidden', ...SHADOW.md,
  },
  cardHeader: {
    flexDirection: 'row', alignItems: 'center', gap: SPACING.sm,
    padding: SPACING.md, borderBottomWidth: 1, borderBottomColor: COLORS.border,
  },
  passagerAvatar: {
    width: 40, height: 40, borderRadius: 20,
    backgroundColor: `${COLORS.primary}15`,
    justifyContent: 'center', alignItems: 'center',
  },
  passagerAvatarLetter: { fontSize: FONTS.lg, fontWeight: '800', color: COLORS.primary },
  passagerName: { fontSize: FONTS.md, fontWeight: '800', color: COLORS.text },
  cardDateTime: { fontSize: FONTS.xs, color: COLORS.textLight, marginTop: 2 },
  pendingBadge: {
    flexDirection: 'row', alignItems: 'center', gap: 4,
    backgroundColor: '#FEF3C7', paddingHorizontal: SPACING.sm, paddingVertical: 4,
    borderRadius: RADIUS.full,
  },
  pendingDot: { width: 6, height: 6, borderRadius: 3, backgroundColor: '#D97706' },
  pendingText: { fontSize: FONTS.xs, fontWeight: '700', color: '#D97706' },

  route: { flexDirection: 'row', alignItems: 'center', padding: SPACING.md, gap: SPACING.sm },
  routePoint: { flex: 1, alignItems: 'center', gap: 4 },
  routeIconWrapper: { width: 36, height: 36, borderRadius: 18, justifyContent: 'center', alignItems: 'center' },
  routeLabel: { fontSize: FONTS.xs, color: COLORS.textLight, fontWeight: '600', textTransform: 'uppercase' },
  routeCity: { fontSize: FONTS.sm, fontWeight: '800', color: COLORS.text, textAlign: 'center' },
  routeMid: { flexDirection: 'row', alignItems: 'center', gap: 2 },
  dottedLine: { width: 14, height: 1, backgroundColor: COLORS.border },

  actions: {
    flexDirection: 'row', gap: SPACING.sm, padding: SPACING.md, paddingTop: 0,
  },
  refuserBtn: {
    flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6,
    height: 44, borderRadius: RADIUS.md,
    backgroundColor: '#FEE2E2', borderWidth: 1, borderColor: '#FECACA',
  },
  refuserText: { fontSize: FONTS.sm, fontWeight: '700', color: COLORS.error },
  accepterBtn: { flex: 2, borderRadius: RADIUS.md, overflow: 'hidden' },
  accepterGradient: {
    height: 44, flexDirection: 'row',
    alignItems: 'center', justifyContent: 'center', gap: 6,
  },
  accepterText: { fontSize: FONTS.sm, fontWeight: '700', color: '#fff' },

  empty: { alignItems: 'center', marginTop: 80, gap: SPACING.sm },
  emptyTitle: { fontSize: FONTS.xl, fontWeight: '800', color: COLORS.text, marginTop: SPACING.sm },
  emptySub: { fontSize: FONTS.sm, color: COLORS.textLight, textAlign: 'center' },
});
