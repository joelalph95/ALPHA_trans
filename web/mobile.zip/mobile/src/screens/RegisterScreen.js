import React, { useState } from 'react';
import {
  View, Text, TextInput, TouchableOpacity,
  StyleSheet, KeyboardAvoidingView, Platform,
  ActivityIndicator, Alert, ScrollView,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../context/AuthContext';
import { register } from '../api/client';
import { COLORS, FONTS, SPACING, RADIUS, SHADOW } from '../utils/theme';

export default function RegisterScreen({ navigation }) {
  const { signIn } = useAuth();
  const [form, setForm] = useState({
    nom: '', telephone: '', email: '', mot_de_passe: ''
  });
  const [role, setRole] = useState('passager');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);

  const updateField = (field, value) => setForm(prev => ({ ...prev, [field]: value }));

  const handleRegister = async () => {
    if (!form.nom || !form.email || !form.mot_de_passe) {
      Alert.alert('Champs manquants', 'Nom, email et mot de passe sont obligatoires.');
      return;
    }
    setLoading(true);
    try {
      await register(form.nom, form.email, form.mot_de_passe, role, form.telephone);
      // Auto-login after register
      const { login: loginFn } = require('../api/client');
      const data = await loginFn(form.email, form.mot_de_passe);
      await signIn(data.user, data.token);
    } catch (err) {
      Alert.alert('Erreur', err.message || 'Impossible de créer le compte.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <ScrollView showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled">
        {/* Header */}
        <LinearGradient
          colors={[COLORS.primaryDark, COLORS.primary]}
          style={styles.header}
        >
          <View style={styles.decorCircle1} />
          <View style={styles.decorCircle2} />
          <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
            <Ionicons name="arrow-back" size={22} color="#fff" />
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Créer un compte</Text>
          <Text style={styles.headerSub}>Rejoignez SmartTransport</Text>
        </LinearGradient>

        <View style={styles.form}>
          {/* Role selector */}
          <View style={styles.roleSection}>
            <Text style={styles.roleLabel}>Vous êtes ?</Text>
            <View style={styles.roleButtons}>
              <TouchableOpacity
                style={[styles.roleBtn, role === 'passager' && styles.roleBtnActive]}
                onPress={() => setRole('passager')}
              >
                <Ionicons
                  name="person"
                  size={20}
                  color={role === 'passager' ? '#fff' : COLORS.primary}
                />
                <Text style={[styles.roleBtnText, role === 'passager' && styles.roleBtnTextActive]}>
                  Passager
                </Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.roleBtn, role === 'chauffeur' && styles.roleBtnActive]}
                onPress={() => setRole('chauffeur')}
              >
                <Ionicons
                  name="car"
                  size={20}
                  color={role === 'chauffeur' ? '#fff' : COLORS.primary}
                />
                <Text style={[styles.roleBtnText, role === 'chauffeur' && styles.roleBtnTextActive]}>
                  Chauffeur
                </Text>
              </TouchableOpacity>
            </View>
          </View>

          {/* Nom */}
          <InputField
            label="Nom complet"
            icon="person-outline"
            placeholder="Jean Rakoto"
            value={form.nom}
            onChangeText={v => updateField('nom', v)}
          />

          {/* Téléphone */}
          <InputField
            label="Téléphone"
            icon="call-outline"
            placeholder="+261 34 000 0000"
            value={form.telephone}
            onChangeText={v => updateField('telephone', v)}
            keyboardType="phone-pad"
          />

          {/* Email */}
          <InputField
            label="Adresse e-mail"
            icon="mail-outline"
            placeholder="exemple@mail.com"
            value={form.email}
            onChangeText={v => updateField('email', v)}
            keyboardType="email-address"
            autoCapitalize="none"
          />

          {/* Password */}
          <View style={styles.inputWrapper}>
            <Text style={styles.label}>Mot de passe</Text>
            <View style={styles.inputContainer}>
              <Ionicons name="lock-closed-outline" size={18} color={COLORS.textLight} style={styles.inputIcon} />
              <TextInput
                style={[styles.input, { flex: 1 }]}
                placeholder="Minimum 6 caractères"
                placeholderTextColor={COLORS.textLight}
                value={form.mot_de_passe}
                onChangeText={v => updateField('mot_de_passe', v)}
                secureTextEntry={!showPassword}
              />
              <TouchableOpacity onPress={() => setShowPassword(!showPassword)}>
                <Ionicons name={showPassword ? 'eye-off-outline' : 'eye-outline'} size={18} color={COLORS.textLight} />
              </TouchableOpacity>
            </View>
          </View>

          {/* Submit */}
          <TouchableOpacity
            style={styles.submitBtn}
            onPress={handleRegister}
            disabled={loading}
            activeOpacity={0.85}
          >
            <LinearGradient
              colors={[COLORS.primary, '#2D6A4F']}
              style={styles.submitGradient}
              start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}
            >
              {loading ? (
                <ActivityIndicator color="#fff" />
              ) : (
                <>
                  <Text style={styles.submitText}>Créer mon compte</Text>
                  <Ionicons name="checkmark-circle-outline" size={20} color="#fff" />
                </>
              )}
            </LinearGradient>
          </TouchableOpacity>

          {/* Already have account */}
          <View style={styles.loginRow}>
            <Text style={styles.loginText}>Déjà un compte ? </Text>
            <TouchableOpacity onPress={() => navigation.goBack()}>
              <Text style={styles.loginLink}>Se connecter</Text>
            </TouchableOpacity>
          </View>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const InputField = ({ label, icon, placeholder, value, onChangeText, keyboardType, autoCapitalize }) => (
  <View style={styles.inputWrapper}>
    <Text style={styles.label}>{label}</Text>
    <View style={styles.inputContainer}>
      <Ionicons name={icon} size={18} color={COLORS.textLight} style={styles.inputIcon} />
      <TextInput
        style={styles.input}
        placeholder={placeholder}
        placeholderTextColor={COLORS.textLight}
        value={value}
        onChangeText={onChangeText}
        keyboardType={keyboardType || 'default'}
        autoCapitalize={autoCapitalize || 'words'}
      />
    </View>
  </View>
);

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.background },

  header: {
    paddingTop: 55, paddingBottom: SPACING.xl,
    paddingHorizontal: SPACING.lg,
    overflow: 'hidden',
  },
  decorCircle1: {
    position: 'absolute', top: -30, right: -30,
    width: 130, height: 130, borderRadius: 65,
    backgroundColor: 'rgba(249,115,22,0.12)',
  },
  decorCircle2: {
    position: 'absolute', bottom: 10, left: -20,
    width: 90, height: 90, borderRadius: 45,
    backgroundColor: 'rgba(82,183,136,0.15)',
  },
  backBtn: {
    width: 38, height: 38, borderRadius: 19,
    backgroundColor: 'rgba(255,255,255,0.15)',
    justifyContent: 'center', alignItems: 'center',
    marginBottom: SPACING.md,
  },
  headerTitle: {
    fontSize: FONTS.xxl, fontWeight: '800', color: '#fff',
  },
  headerSub: { fontSize: FONTS.sm, color: 'rgba(255,255,255,0.7)', marginTop: 4 },

  form: { padding: SPACING.lg },

  roleSection: { marginBottom: SPACING.lg },
  roleLabel: {
    fontSize: FONTS.sm, fontWeight: '700',
    color: COLORS.text, marginBottom: SPACING.sm,
  },
  roleButtons: { flexDirection: 'row', gap: SPACING.md },
  roleBtn: {
    flex: 1, flexDirection: 'row', alignItems: 'center',
    justifyContent: 'center', gap: SPACING.sm,
    height: 48, borderRadius: RADIUS.md,
    borderWidth: 2, borderColor: COLORS.primary,
    backgroundColor: 'transparent',
  },
  roleBtnActive: {
    backgroundColor: COLORS.primary,
  },
  roleBtnText: {
    fontSize: FONTS.md, fontWeight: '700', color: COLORS.primary,
  },
  roleBtnTextActive: { color: '#fff' },

  inputWrapper: { marginBottom: SPACING.md },
  label: {
    fontSize: FONTS.sm, fontWeight: '600',
    color: COLORS.text, marginBottom: SPACING.xs,
  },
  inputContainer: {
    flexDirection: 'row', alignItems: 'center',
    backgroundColor: COLORS.card, borderRadius: RADIUS.md,
    borderWidth: 1.5, borderColor: COLORS.border,
    paddingHorizontal: SPACING.md, height: 52,
    ...SHADOW.sm,
  },
  inputIcon: { marginRight: SPACING.sm },
  input: { flex: 1, fontSize: FONTS.md, color: COLORS.text },

  submitBtn: { marginTop: SPACING.md, borderRadius: RADIUS.md, overflow: 'hidden', ...SHADOW.md },
  submitGradient: {
    height: 54, flexDirection: 'row',
    alignItems: 'center', justifyContent: 'center', gap: 8,
  },
  submitText: { fontSize: FONTS.md, fontWeight: '700', color: '#fff' },

  loginRow: {
    flexDirection: 'row', justifyContent: 'center',
    marginTop: SPACING.lg, alignItems: 'center',
  },
  loginText: { fontSize: FONTS.sm, color: COLORS.textLight },
  loginLink: {
    fontSize: FONTS.sm, fontWeight: '700',
    color: COLORS.primary, textDecorationLine: 'underline',
  },
});
