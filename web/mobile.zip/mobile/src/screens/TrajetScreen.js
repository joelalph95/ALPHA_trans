import React, { useState, useEffect, useRef } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity,
  ActivityIndicator, ScrollView, Animated,
} from 'react-native';
import MapView, { Marker, Polyline, Circle } from 'react-native-maps';
import * as Location from 'expo-location';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { COLORS, FONTS, SPACING, RADIUS, SHADOW } from '../utils/theme';

const haversine = (lat1, lon1, lat2, lon2) => {
  const R = 6371;
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a = Math.sin(dLat/2)**2 + Math.cos(lat1*Math.PI/180)*Math.cos(lat2*Math.PI/180)*Math.sin(dLon/2)**2;
  return (R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a))).toFixed(1);
};

export default function TrajetScreen({ navigation, route }) {
  const demande = route.params?.demande;
  const [location, setLocation] = useState(null);
  const [permissionGranted, setPermissionGranted] = useState(false);
  const [loading, setLoading] = useState(true);
  const mapRef = useRef(null);
  const pulseAnim = useRef(new Animated.Value(1)).current;

  // Pulse animation for location dot
  useEffect(() => {
    Animated.loop(
      Animated.sequence([
        Animated.timing(pulseAnim, { toValue: 1.4, duration: 800, useNativeDriver: true }),
        Animated.timing(pulseAnim, { toValue: 1, duration: 800, useNativeDriver: true }),
      ])
    ).start();
  }, []);

  useEffect(() => {
    (async () => {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status === 'granted') {
        setPermissionGranted(true);
        const loc = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.High });
        setLocation(loc.coords);

        // Watch position updates
        Location.watchPositionAsync(
          { accuracy: Location.Accuracy.High, timeInterval: 5000, distanceInterval: 10 },
          (newLoc) => setLocation(newLoc.coords)
        );
      }
      setLoading(false);
    })();
  }, []);

  const depart = demande ? { latitude: parseFloat(demande.lat_dep || -18.9137), longitude: parseFloat(demande.lon_dep || 47.5361) } : null;
  const arrivee = demande ? { latitude: parseFloat(demande.lat_arr || -20.2894), longitude: parseFloat(demande.lon_arr || 44.2948) } : null;

  const distanceRestante = location && arrivee
    ? haversine(location.latitude, location.longitude, arrivee.latitude, arrivee.longitude)
    : null;

  const mapRegion = location ? {
    latitude: location.latitude,
    longitude: location.longitude,
    latitudeDelta: 0.08,
    longitudeDelta: 0.08,
  } : {
    latitude: -18.9137,
    longitude: 47.5361,
    latitudeDelta: 3,
    longitudeDelta: 3,
  };

  const centerOnLocation = () => {
    if (location && mapRef.current) {
      mapRef.current.animateToRegion({
        latitude: location.latitude,
        longitude: location.longitude,
        latitudeDelta: 0.05,
        longitudeDelta: 0.05,
      }, 500);
    }
  };

  return (
    <View style={styles.container}>
      {/* Map takes most of the screen */}
      {loading ? (
        <View style={styles.mapLoader}>
          <ActivityIndicator size="large" color={COLORS.primary} />
          <Text style={styles.mapLoaderText}>Localisation en cours...</Text>
        </View>
      ) : (
        <MapView
          ref={mapRef}
          style={styles.map}
          region={mapRegion}
          showsUserLocation={false}
          showsCompass
          showsScale
        >
          {/* Current position */}
          {location && (
            <>
              <Circle
                center={location}
                radius={80}
                strokeColor={`${COLORS.primary}40`}
                fillColor={`${COLORS.primary}20`}
              />
              <Marker coordinate={location} title="Ma position">
                <View style={styles.myLocationMarker}>
                  <View style={styles.myLocationDot} />
                </View>
              </Marker>
            </>
          )}

          {/* Départ */}
          {depart && (
            <Marker coordinate={depart} title={demande?.ville_depart || 'Départ'}>
              <View style={[styles.customMarker, { backgroundColor: COLORS.primary }]}>
                <Ionicons name="location" size={16} color="#fff" />
              </View>
            </Marker>
          )}

          {/* Arrivée */}
          {arrivee && (
            <Marker coordinate={arrivee} title={demande?.ville_arrivee || 'Arrivée'}>
              <View style={[styles.customMarker, { backgroundColor: COLORS.accent }]}>
                <Ionicons name="flag" size={16} color="#fff" />
              </View>
            </Marker>
          )}

          {/* Route line */}
          {depart && arrivee && (
            <Polyline
              coordinates={[depart, ...(location ? [location] : []), arrivee]}
              strokeColor={COLORS.primary}
              strokeWidth={3}
              lineDashPattern={[1]}
            />
          )}
        </MapView>
      )}

      {/* Header overlay */}
      <View style={styles.headerOverlay}>
        <LinearGradient
          colors={['rgba(27,67,50,0.95)', 'rgba(27,67,50,0.7)', 'transparent']}
          style={styles.headerGradient}
        >
          <View style={styles.headerContent}>
            <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
              <Ionicons name="arrow-back" size={20} color="#fff" />
            </TouchableOpacity>
            <Text style={styles.headerTitle}>Trajet</Text>
            <View style={styles.liveIndicator}>
              <Animated.View style={[styles.liveDot, { transform: [{ scale: pulseAnim }] }]} />
              <Text style={styles.liveText}>EN DIRECT</Text>
            </View>
          </View>
        </LinearGradient>
      </View>

      {/* Center button */}
      {location && (
        <TouchableOpacity style={styles.centerBtn} onPress={centerOnLocation}>
          <Ionicons name="navigate" size={22} color={COLORS.primary} />
        </TouchableOpacity>
      )}

      {/* Bottom info panel */}
      <View style={styles.bottomPanel}>
        <View style={styles.panelHandle} />

        {/* Route info */}
        {demande ? (
          <View style={styles.routeInfo}>
            <View style={styles.routePoint}>
              <View style={[styles.routeDot, { backgroundColor: COLORS.primary }]} />
              <View>
                <Text style={styles.routeLabel}>Départ</Text>
                <Text style={styles.routeCity}>{demande.ville_depart}</Text>
              </View>
            </View>
            <View style={styles.routeConnector}>
              <View style={styles.routeConnectorLine} />
              <Ionicons name="arrow-forward" size={16} color={COLORS.textLight} />
              <View style={styles.routeConnectorLine} />
            </View>
            <View style={styles.routePoint}>
              <View style={[styles.routeDot, { backgroundColor: COLORS.accent }]} />
              <View>
                <Text style={styles.routeLabel}>Arrivée</Text>
                <Text style={styles.routeCity}>{demande.ville_arrivee}</Text>
              </View>
            </View>
          </View>
        ) : (
          <Text style={styles.noTripText}>Aucun trajet sélectionné</Text>
        )}

        {/* Stats row */}
        <View style={styles.statsRow}>
          <StatItem
            icon="navigate-outline"
            value={distanceRestante ? `${distanceRestante} km` : '—'}
            label="Distance restante"
            color={COLORS.primary}
          />
          <StatItem
            icon="location-outline"
            value={location ? `${location.latitude.toFixed(4)}` : '—'}
            label="Latitude actuelle"
            color='#7C3AED'
          />
          <StatItem
            icon="speedometer-outline"
            value={location?.speed ? `${(location.speed * 3.6).toFixed(0)} km/h` : '0 km/h'}
            label="Vitesse"
            color={COLORS.accent}
          />
        </View>

        {!permissionGranted && (
          <View style={styles.permissionWarning}>
            <Ionicons name="warning-outline" size={16} color={COLORS.warning} />
            <Text style={styles.permissionText}>
              Localisation non autorisée. Activez-la dans les paramètres.
            </Text>
          </View>
        )}
      </View>
    </View>
  );
}

const StatItem = ({ icon, value, label, color }) => (
  <View style={styles.statItem}>
    <Ionicons name={icon} size={18} color={color} />
    <Text style={[styles.statValue, { color }]}>{value}</Text>
    <Text style={styles.statLabel}>{label}</Text>
  </View>
);

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.background },

  map: { flex: 1 },
  mapLoader: {
    flex: 1, justifyContent: 'center', alignItems: 'center',
    backgroundColor: COLORS.surface,
  },
  mapLoaderText: { marginTop: SPACING.md, color: COLORS.textLight, fontSize: FONTS.md },

  // Custom markers
  myLocationMarker: {
    width: 24, height: 24, borderRadius: 12,
    backgroundColor: 'rgba(27,67,50,0.2)',
    justifyContent: 'center', alignItems: 'center',
    borderWidth: 2, borderColor: COLORS.primary,
  },
  myLocationDot: {
    width: 10, height: 10, borderRadius: 5,
    backgroundColor: COLORS.primary,
  },
  customMarker: {
    width: 36, height: 36, borderRadius: 18,
    justifyContent: 'center', alignItems: 'center',
    borderWidth: 2, borderColor: '#fff',
    ...SHADOW.md,
  },

  // Header overlay
  headerOverlay: { position: 'absolute', top: 0, left: 0, right: 0 },
  headerGradient: { paddingTop: 48, paddingBottom: SPACING.xl, paddingHorizontal: SPACING.lg },
  headerContent: { flexDirection: 'row', alignItems: 'center', gap: SPACING.md },
  backBtn: {
    width: 36, height: 36, borderRadius: 18,
    backgroundColor: 'rgba(255,255,255,0.15)',
    justifyContent: 'center', alignItems: 'center',
  },
  headerTitle: { fontSize: FONTS.lg, fontWeight: '800', color: '#fff', flex: 1 },
  liveIndicator: {
    flexDirection: 'row', alignItems: 'center', gap: 5,
    backgroundColor: 'rgba(239,68,68,0.2)',
    paddingHorizontal: SPACING.sm, paddingVertical: 4,
    borderRadius: RADIUS.full,
    borderWidth: 1, borderColor: 'rgba(239,68,68,0.4)',
  },
  liveDot: { width: 7, height: 7, borderRadius: 3.5, backgroundColor: '#EF4444' },
  liveText: { fontSize: FONTS.xs, fontWeight: '800', color: '#EF4444', letterSpacing: 0.5 },

  // Center button
  centerBtn: {
    position: 'absolute', right: SPACING.lg, bottom: 260,
    width: 44, height: 44, borderRadius: 22,
    backgroundColor: '#fff', justifyContent: 'center', alignItems: 'center',
    ...SHADOW.md,
  },

  // Bottom panel
  bottomPanel: {
    backgroundColor: '#fff',
    borderTopLeftRadius: RADIUS.xl, borderTopRightRadius: RADIUS.xl,
    paddingTop: SPACING.sm, paddingHorizontal: SPACING.lg, paddingBottom: 30,
    ...SHADOW.lg,
  },
  panelHandle: {
    width: 36, height: 4, backgroundColor: COLORS.border,
    borderRadius: 2, alignSelf: 'center', marginBottom: SPACING.md,
  },
  routeInfo: {
    flexDirection: 'row', alignItems: 'center',
    backgroundColor: COLORS.surface, borderRadius: RADIUS.lg,
    padding: SPACING.md, marginBottom: SPACING.md,
  },
  routePoint: { flexDirection: 'row', alignItems: 'center', gap: SPACING.sm, flex: 1 },
  routeDot: { width: 12, height: 12, borderRadius: 6 },
  routeLabel: { fontSize: FONTS.xs, color: COLORS.textLight, textTransform: 'uppercase', fontWeight: '700' },
  routeCity: { fontSize: FONTS.md, fontWeight: '800', color: COLORS.text },
  routeConnector: { flexDirection: 'row', alignItems: 'center', gap: 2, paddingHorizontal: SPACING.xs },
  routeConnectorLine: { width: 12, height: 1, backgroundColor: COLORS.border },

  noTripText: {
    textAlign: 'center', color: COLORS.textLight,
    fontSize: FONTS.md, marginBottom: SPACING.md,
  },

  statsRow: {
    flexDirection: 'row', gap: SPACING.sm,
  },
  statItem: {
    flex: 1, backgroundColor: COLORS.surface,
    borderRadius: RADIUS.md, padding: SPACING.sm,
    alignItems: 'center', gap: 3,
  },
  statValue: { fontSize: FONTS.md, fontWeight: '800' },
  statLabel: { fontSize: 9, color: COLORS.textLight, textAlign: 'center', fontWeight: '600' },

  permissionWarning: {
    flexDirection: 'row', alignItems: 'center', gap: SPACING.sm,
    backgroundColor: '#FEF3C7', borderRadius: RADIUS.md,
    padding: SPACING.sm, marginTop: SPACING.sm,
  },
  permissionText: { flex: 1, fontSize: FONTS.xs, color: '#92400E' },
});
