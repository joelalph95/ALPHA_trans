import React, { useState, useEffect } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity,
  ScrollView, ActivityIndicator, Alert, Modal, FlatList,
} from 'react-native';
import MapView, { Marker, Polyline } from 'react-native-maps';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { getVilles, createDemande } from '../api/client';
import { COLORS, FONTS, SPACING, RADIUS, SHADOW } from '../utils/theme';

const haversine = (lat1, lon1, lat2, lon2) => {
  const R = 6371;
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a = Math.sin(dLat/2)**2 + Math.cos(lat1*Math.PI/180)*Math.cos(lat2*Math.PI/180)*Math.sin(dLon/2)**2;
  return Math.round(R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a)));
};

export default function ReservationScreen({ navigation }) {
  const [villes, setVilles] = useState([]);
  const [depart, setDepart] = useState(null);
  const [arrivee, setArrivee] = useState(null);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [modalTarget, setModalTarget] = useState(null); // 'depart' | 'arrivee'

  useEffect(() => {
    getVilles()
      .then(setVilles)
      .catch(e => Alert.alert('Erreur', e.message))
      .finally(() => setLoading(false));
  }, []);

  const distance = depart && arrivee
    ? haversine(depart.latitude, depart.longitude, arrivee.latitude, arrivee.longitude)
    : null;

  const mapRegion = depart && arrivee ? {
    latitude: (depart.latitude + arrivee.latitude) / 2,
    longitude: (depart.longitude + arrivee.longitude) / 2,
    latitudeDelta: Math.abs(depart.latitude - arrivee.latitude) * 2 + 0.1,
    longitudeDelta: Math.abs(depart.longitude - arrivee.longitude) * 2 + 0.1,
  } : {
    latitude: -18.9137,
    longitude: 47.5361,
    latitudeDelta: 4,
    longitudeDelta: 4,
  };

  const handleReserver = async () => {
    if (!depart || !arrivee) {
      Alert.alert('Incomplet', 'Choisissez la ville de départ et d\'arrivée.');
      return;
    }
    if (depart.id === arrivee.id) {
      Alert.alert('Erreur', 'Le départ et l\'arrivée doivent être différents.');
      return;
    }
    setSubmitting(true);
    try {
      await createDemande(depart.id, arrivee.id);
      Alert.alert('✅ Réservation envoyée !', 'Votre demande est en cours de traitement.', [
        { text: 'OK', onPress: () => navigation.goBack() }
      ]);
    } catch (e) {
      Alert.alert('Erreur', e.message);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <View style={styles.container}>
      {/* Header */}
      <LinearGradient
        colors={[COLORS.primary, '#2D6A4F']}
        style={styles.header}
      >
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
          <Ionicons name="arrow-back" size={22} color="#fff" />
        </TouchableOpacity>
        <View>
          <Text style={styles.headerTitle}>Réservation</Text>
          <Text style={styles.headerSub}>Choisir votre trajet</Text>
        </View>
      </LinearGradient>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        {/* City selectors */}
        <View style={styles.card}>
          {/* Depart */}
          <View style={styles.cityRow}>
            <View style={[styles.cityDot, { backgroundColor: COLORS.primary }]} />
            <View style={{ flex: 1 }}>
              <Text style={styles.cityLabel}>Départ</Text>
              <TouchableOpacity
                style={styles.citySelector}
                onPress={() => setModalTarget('depart')}
              >
                <Ionicons name="location-outline" size={18} color={COLORS.primary} />
                <Text style={[styles.citySelectorText, !depart && styles.placeholder]}>
                  {depart ? depart.nom : 'Choisir la ville...'}
                </Text>
                <Ionicons name="chevron-down" size={16} color={COLORS.textLight} />
              </TouchableOpacity>
            </View>
          </View>

          {/* Vertical line */}
          <View style={styles.routeLine}>
            <View style={styles.routeLineInner} />
            <Ionicons name="arrow-down" size={14} color={COLORS.textLight} />
          </View>

          {/* Arrivée */}
          <View style={styles.cityRow}>
            <View style={[styles.cityDot, { backgroundColor: COLORS.accent }]} />
            <View style={{ flex: 1 }}>
              <Text style={styles.cityLabel}>Arrivée</Text>
              <TouchableOpacity
                style={styles.citySelector}
                onPress={() => setModalTarget('arrivee')}
              >
                <Ionicons name="flag-outline" size={18} color={COLORS.accent} />
                <Text style={[styles.citySelectorText, !arrivee && styles.placeholder]}>
                  {arrivee ? arrivee.nom : 'Choisir la ville...'}
                </Text>
                <Ionicons name="chevron-down" size={16} color={COLORS.textLight} />
              </TouchableOpacity>
            </View>
          </View>
        </View>

        {/* Trip Details */}
        {depart && arrivee && (
          <View style={styles.detailsCard}>
            <Text style={styles.detailsTitle}>Détails du voyage</Text>
            <View style={styles.detailsRow}>
              <View style={styles.detailItem}>
                <Ionicons name="location" size={18} color={COLORS.primary} />
                <Text style={styles.detailValue}>{distance} km</Text>
                <Text style={styles.detailLabel}>Distance</Text>
              </View>
              <View style={styles.detailDivider} />
              <View style={styles.detailItem}>
                <Ionicons name="cash-outline" size={18} color={COLORS.accent} />
                <Text style={styles.detailValue}>{(distance * 150).toLocaleString()} Ar</Text>
                <Text style={styles.detailLabel}>Tarif estimé</Text>
              </View>
              <View style={styles.detailDivider} />
              <View style={styles.detailItem}>
                <Ionicons name="time-outline" size={18} color='#7C3AED' />
                <Text style={styles.detailValue}>~{Math.ceil(distance / 60)}h</Text>
                <Text style={styles.detailLabel}>Durée</Text>
              </View>
            </View>
          </View>
        )}

        {/* Map */}
        <View style={styles.mapContainer}>
          <Text style={styles.mapTitle}>
            {depart && arrivee ? `Map selon les villes sélectionnées` : 'Carte interactive'}
          </Text>
          {loading ? (
            <View style={styles.mapPlaceholder}>
              <ActivityIndicator color={COLORS.primary} />
            </View>
          ) : (
            <MapView style={styles.map} region={mapRegion} showsUserLocation>
              {depart && (
                <Marker
                  coordinate={{ latitude: depart.latitude, longitude: depart.longitude }}
                  title={`Départ: ${depart.nom}`}
                  pinColor={COLORS.primary}
                />
              )}
              {arrivee && (
                <Marker
                  coordinate={{ latitude: arrivee.latitude, longitude: arrivee.longitude }}
                  title={`Arrivée: ${arrivee.nom}`}
                  pinColor={COLORS.accent}
                />
              )}
              {depart && arrivee && (
                <Polyline
                  coordinates={[
                    { latitude: depart.latitude, longitude: depart.longitude },
                    { latitude: arrivee.latitude, longitude: arrivee.longitude },
                  ]}
                  strokeColor={COLORS.primary}
                  strokeWidth={3}
                  lineDashPattern={[8, 4]}
                />
              )}
            </MapView>
          )}
        </View>

        {/* Reserve Button */}
        <TouchableOpacity
          style={[styles.reserveBtn, (!depart || !arrivee) && styles.reserveBtnDisabled]}
          onPress={handleReserver}
          disabled={submitting || !depart || !arrivee}
          activeOpacity={0.85}
        >
          <LinearGradient
            colors={depart && arrivee ? [COLORS.accent, '#EA580C'] : [COLORS.border, COLORS.border]}
            style={styles.reserveGradient}
            start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}
          >
            {submitting ? (
              <ActivityIndicator color="#fff" />
            ) : (
              <>
                <Ionicons name="checkmark-circle-outline" size={22} color="#fff" />
                <Text style={styles.reserveBtnText}>Confirmer la réservation</Text>
              </>
            )}
          </LinearGradient>
        </TouchableOpacity>

        <View style={{ height: 40 }} />
      </ScrollView>

      {/* City Picker Modal */}
      <Modal
        visible={!!modalTarget}
        animationType="slide"
        transparent
        onRequestClose={() => setModalTarget(null)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalSheet}>
            <View style={styles.modalHandle} />
            <Text style={styles.modalTitle}>
              {modalTarget === 'depart' ? '📍 Ville de départ' : '🏁 Ville d\'arrivée'}
            </Text>
            <FlatList
              data={villes}
              keyExtractor={item => item.id.toString()}
              renderItem={({ item }) => (
                <TouchableOpacity
                  style={styles.villeItem}
                  onPress={() => {
                    if (modalTarget === 'depart') setDepart(item);
                    else setArrivee(item);
                    setModalTarget(null);
                  }}
                >
                  <Ionicons
                    name="location-outline"
                    size={18}
                    color={modalTarget === 'depart' ? COLORS.primary : COLORS.accent}
                  />
                  <Text style={styles.villeItemText}>{item.nom}</Text>
                  <Ionicons name="chevron-forward" size={14} color={COLORS.textLight} />
                </TouchableOpacity>
              )}
              ItemSeparatorComponent={() => <View style={styles.villeItemSep} />}
            />
            <TouchableOpacity style={styles.modalClose} onPress={() => setModalTarget(null)}>
              <Text style={styles.modalCloseText}>Annuler</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.background },

  header: {
    flexDirection: 'row', alignItems: 'center', gap: SPACING.md,
    paddingTop: 55, paddingBottom: SPACING.lg, paddingHorizontal: SPACING.lg,
  },
  backBtn: {
    width: 38, height: 38, borderRadius: 19,
    backgroundColor: 'rgba(255,255,255,0.15)',
    justifyContent: 'center', alignItems: 'center',
  },
  headerTitle: { fontSize: FONTS.xl, fontWeight: '800', color: '#fff' },
  headerSub: { fontSize: FONTS.sm, color: 'rgba(255,255,255,0.7)' },

  content: { flex: 1 },

  card: {
    margin: SPACING.lg, backgroundColor: COLORS.card,
    borderRadius: RADIUS.xl, padding: SPACING.lg, ...SHADOW.md,
  },
  cityRow: { flexDirection: 'row', alignItems: 'flex-start', gap: SPACING.md },
  cityDot: { width: 12, height: 12, borderRadius: 6, marginTop: 30 },
  cityLabel: { fontSize: FONTS.xs, fontWeight: '700', color: COLORS.textLight, textTransform: 'uppercase', letterSpacing: 0.8 },
  citySelector: {
    flexDirection: 'row', alignItems: 'center', gap: SPACING.sm,
    backgroundColor: COLORS.surface, borderRadius: RADIUS.md,
    paddingHorizontal: SPACING.md, height: 48, marginTop: 4,
    borderWidth: 1.5, borderColor: COLORS.border,
  },
  citySelectorText: { flex: 1, fontSize: FONTS.md, fontWeight: '700', color: COLORS.text },
  placeholder: { color: COLORS.textLight, fontWeight: '400' },

  routeLine: { alignItems: 'center', paddingVertical: SPACING.xs, paddingLeft: 6 },
  routeLineInner: { width: 1, height: 12, backgroundColor: COLORS.border, marginBottom: 2 },

  detailsCard: {
    marginHorizontal: SPACING.lg, backgroundColor: COLORS.card,
    borderRadius: RADIUS.xl, padding: SPACING.lg, ...SHADOW.sm,
    marginBottom: SPACING.md,
  },
  detailsTitle: { fontSize: FONTS.md, fontWeight: '800', color: COLORS.text, marginBottom: SPACING.md },
  detailsRow: { flexDirection: 'row', alignItems: 'center' },
  detailItem: { flex: 1, alignItems: 'center', gap: 4 },
  detailValue: { fontSize: FONTS.lg, fontWeight: '800', color: COLORS.text },
  detailLabel: { fontSize: FONTS.xs, color: COLORS.textLight },
  detailDivider: { width: 1, height: 40, backgroundColor: COLORS.border },

  mapContainer: {
    marginHorizontal: SPACING.lg, marginBottom: SPACING.md,
    borderRadius: RADIUS.xl, overflow: 'hidden', ...SHADOW.md,
  },
  mapTitle: {
    fontSize: FONTS.sm, fontWeight: '700', color: COLORS.text,
    padding: SPACING.md, backgroundColor: COLORS.card,
  },
  mapPlaceholder: {
    height: 220, backgroundColor: COLORS.surface,
    justifyContent: 'center', alignItems: 'center',
  },
  map: { height: 220 },

  reserveBtn: { marginHorizontal: SPACING.lg, borderRadius: RADIUS.lg, overflow: 'hidden', ...SHADOW.md },
  reserveBtnDisabled: { opacity: 0.6 },
  reserveGradient: {
    height: 54, flexDirection: 'row',
    alignItems: 'center', justifyContent: 'center', gap: 8,
  },
  reserveBtnText: { fontSize: FONTS.md, fontWeight: '700', color: '#fff' },

  // Modal
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'flex-end' },
  modalSheet: {
    backgroundColor: '#fff', borderTopLeftRadius: RADIUS.xl,
    borderTopRightRadius: RADIUS.xl, maxHeight: '75%',
    paddingTop: SPACING.sm,
  },
  modalHandle: {
    width: 36, height: 4, backgroundColor: COLORS.border,
    borderRadius: 2, alignSelf: 'center', marginBottom: SPACING.md,
  },
  modalTitle: {
    fontSize: FONTS.lg, fontWeight: '800', color: COLORS.text,
    paddingHorizontal: SPACING.lg, marginBottom: SPACING.sm,
  },
  villeItem: {
    flexDirection: 'row', alignItems: 'center', gap: SPACING.md,
    paddingHorizontal: SPACING.lg, paddingVertical: SPACING.md,
  },
  villeItemText: { flex: 1, fontSize: FONTS.md, fontWeight: '600', color: COLORS.text },
  villeItemSep: { height: 1, backgroundColor: COLORS.border, marginHorizontal: SPACING.lg },
  modalClose: {
    margin: SPACING.lg, backgroundColor: COLORS.surface,
    borderRadius: RADIUS.md, padding: SPACING.md, alignItems: 'center',
  },
  modalCloseText: { fontSize: FONTS.md, fontWeight: '700', color: COLORS.text },
});
