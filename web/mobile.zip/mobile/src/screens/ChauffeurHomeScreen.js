import React, { useState, useEffect } from 'react';
import {
  View, Text, ScrollView, StyleSheet,
  TouchableOpacity, RefreshControl,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../context/AuthContext';
import { getAllDemandes, getPlannings } from '../api/client';
import { COLORS, FONTS, SPACING, RADIUS, SHADOW } from '../utils/theme';

export default function ChauffeurHomeScreen({ navigation }) {
  const { user } = useAuth();
  const [demandes, setDemandes] = useState([]);
  const [plannings, setPlannings] = useState([]);
  const [refreshing, setRefreshing] = useState(false);

  const fetchData = async () => {
    try {
      const [d, p] = await Promise.all([getAllDemandes(), getPlannings()]);
      setDemandes(d);
      setPlannings(p);
    } catch (e) {
      console.log('Erreur:', e.message);
    } finally {
      setRefreshing(false);
    }
  };

  useEffect(() => { fetchData(); }, []);

  const menuItems = [
    {
      icon: 'people-outline',
      label: 'Mes Passagers',
      sub: `${demandes.length} demande(s) en attente`,
      color: COLORS.accent,
      onPress: () => navigation.navigate('MesPassagers'),
    },
    {
      icon: 'map-outline',
      label: 'Trajet',
      sub: 'Voir la carte de votre trajet',
      color: COLORS.primary,
      onPress: () => navigation.navigate('Trajet', { demande: null }),
    },
    {
      icon: 'calendar-outline',
      label: 'Planning',
      sub: `${plannings.length} trajet(s) planifié(s)`,
      color: '#7C3AED',
      onPress: () => navigation.navigate('Planning'),
    },
    {
      icon: 'person-outline',
      label: 'Mon Profil',
      sub: 'Gérer mes informations',
      color: '#0891B2',
      onPress: () => navigation.navigate('Profile'),
    },
  ];

  return (
    <ScrollView
      style={styles.container}
      showsVerticalScrollIndicator={false}
      refreshControl={
        <RefreshControl refreshing={refreshing} onRefresh={() => { setRefreshing(true); fetchData(); }} tintColor={COLORS.primary} />
      }
    >
      {/* Header */}
      <LinearGradient
        colors={['#0B2447', '#19376D', '#1B4332']}
        style={styles.header}
        start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}
      >
        <View style={styles.decor1} />
        <View style={styles.decor2} />
        <View style={styles.decor3} />

        <View style={styles.headerTop}>
          <View style={styles.driverBadge}>
            <Ionicons name="car-sport" size={16} color={COLORS.accent} />
            <Text style={styles.driverBadgeText}>CHAUFFEUR</Text>
          </View>
          <TouchableOpacity onPress={() => navigation.navigate('Profile')} style={styles.avatarBtn}>
            <Ionicons name="person-circle" size={42} color="rgba(255,255,255,0.85)" />
          </TouchableOpacity>
        </View>

        <Text style={styles.greeting}>Bonjour, Chauffeur 👋</Text>
        <Text style={styles.name}>{user?.nom}</Text>

        {/* Stats bar */}
        <View style={styles.statsBar}>
          <View style={styles.statItem}>
            <Text style={styles.statNumber}>{demandes.length}</Text>
            <Text style={styles.statLabel}>Demandes</Text>
          </View>
          <View style={styles.statDivider} />
          <View style={styles.statItem}>
            <Text style={styles.statNumber}>{plannings.filter(p => p.statut === 'en_cours').length}</Text>
            <Text style={styles.statLabel}>En cours</Text>
          </View>
          <View style={styles.statDivider} />
          <View style={styles.statItem}>
            <Text style={styles.statNumber}>{plannings.filter(p => p.statut === 'termine').length}</Text>
            <Text style={styles.statLabel}>Terminés</Text>
          </View>
        </View>
      </LinearGradient>

      {/* Status indicator */}
      <View style={styles.statusBar}>
        <View style={styles.statusDot} />
        <Text style={styles.statusText}>En ligne · Disponible</Text>
        <TouchableOpacity>
          <Text style={styles.statusChange}>Changer</Text>
        </TouchableOpacity>
      </View>

      {/* Menu items */}
      <View style={styles.menu}>
        {menuItems.map((item, i) => (
          <TouchableOpacity
            key={i}
            style={styles.menuItem}
            onPress={item.onPress}
            activeOpacity={0.85}
          >
            <View style={[styles.menuIconWrapper, { backgroundColor: `${item.color}18` }]}>
              <Ionicons name={item.icon} size={26} color={item.color} />
            </View>
            <View style={styles.menuText}>
              <Text style={styles.menuLabel}>{item.label}</Text>
              <Text style={styles.menuSub}>{item.sub}</Text>
            </View>
            <View style={styles.menuArrow}>
              <Ionicons name="chevron-forward" size={18} color={COLORS.textLight} />
            </View>
          </TouchableOpacity>
        ))}
      </View>

      {/* Recent demands */}
      {demandes.length > 0 && (
        <View style={styles.recentSection}>
          <Text style={styles.recentTitle}>Demandes récentes</Text>
          {demandes.slice(0, 3).map((d, i) => (
            <View key={i} style={styles.demandeCard}>
              <Ionicons name="person-outline" size={16} color={COLORS.primary} />
              <View style={{ flex: 1 }}>
                <Text style={styles.demandeName}>{d.passager}</Text>
                <Text style={styles.demandeRoute}>{d.ville_depart} → {d.ville_arrivee}</Text>
              </View>
              <View style={styles.pendingBadge}>
                <Text style={styles.pendingText}>En attente</Text>
              </View>
            </View>
          ))}
        </View>
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.background },

  header: {
    paddingTop: 55, paddingHorizontal: SPACING.lg,
    paddingBottom: SPACING.xl, overflow: 'hidden',
  },
  decor1: {
    position: 'absolute', top: -50, right: -30,
    width: 180, height: 180, borderRadius: 90,
    backgroundColor: 'rgba(249,115,22,0.08)',
  },
  decor2: {
    position: 'absolute', bottom: 20, right: 60,
    width: 80, height: 80, borderRadius: 40,
    backgroundColor: 'rgba(82,183,136,0.1)',
  },
  decor3: {
    position: 'absolute', bottom: -20, left: -20,
    width: 120, height: 120, borderRadius: 60,
    backgroundColor: 'rgba(255,255,255,0.05)',
  },

  headerTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: SPACING.md },
  driverBadge: {
    flexDirection: 'row', alignItems: 'center', gap: 6,
    backgroundColor: 'rgba(249,115,22,0.2)',
    paddingHorizontal: SPACING.sm, paddingVertical: 4,
    borderRadius: RADIUS.full,
    borderWidth: 1, borderColor: 'rgba(249,115,22,0.3)',
  },
  driverBadgeText: {
    fontSize: FONTS.xs, fontWeight: '800',
    color: COLORS.accent, letterSpacing: 1,
  },
  avatarBtn: {},

  greeting: { fontSize: FONTS.md, color: 'rgba(255,255,255,0.7)' },
  name: { fontSize: FONTS.xxxl, fontWeight: '800', color: '#fff', marginBottom: SPACING.lg },

  statsBar: {
    flexDirection: 'row', backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: RADIUS.md, padding: SPACING.md,
    borderWidth: 1, borderColor: 'rgba(255,255,255,0.15)',
  },
  statItem: { flex: 1, alignItems: 'center' },
  statNumber: { fontSize: FONTS.xxl, fontWeight: '800', color: '#fff' },
  statLabel: { fontSize: FONTS.xs, color: 'rgba(255,255,255,0.6)', marginTop: 2 },
  statDivider: { width: 1, backgroundColor: 'rgba(255,255,255,0.2)', marginVertical: 4 },

  statusBar: {
    flexDirection: 'row', alignItems: 'center', gap: SPACING.sm,
    backgroundColor: COLORS.card, marginHorizontal: SPACING.lg,
    marginTop: -20, borderRadius: RADIUS.md, padding: SPACING.md,
    ...SHADOW.md,
  },
  statusDot: {
    width: 10, height: 10, borderRadius: 5,
    backgroundColor: COLORS.success,
  },
  statusText: { flex: 1, fontSize: FONTS.sm, fontWeight: '600', color: COLORS.text },
  statusChange: { fontSize: FONTS.sm, color: COLORS.primary, fontWeight: '700' },

  menu: { padding: SPACING.lg, gap: SPACING.sm, marginTop: SPACING.sm },
  menuItem: {
    flexDirection: 'row', alignItems: 'center',
    backgroundColor: COLORS.card, borderRadius: RADIUS.lg,
    padding: SPACING.md, gap: SPACING.md, ...SHADOW.sm,
  },
  menuIconWrapper: {
    width: 52, height: 52, borderRadius: RADIUS.md,
    justifyContent: 'center', alignItems: 'center',
  },
  menuText: { flex: 1 },
  menuLabel: { fontSize: FONTS.md, fontWeight: '800', color: COLORS.text },
  menuSub: { fontSize: FONTS.xs, color: COLORS.textLight, marginTop: 2 },
  menuArrow: {
    width: 32, height: 32, borderRadius: RADIUS.sm,
    backgroundColor: COLORS.surface,
    justifyContent: 'center', alignItems: 'center',
  },

  recentSection: { paddingHorizontal: SPACING.lg, paddingBottom: SPACING.xl },
  recentTitle: { fontSize: FONTS.lg, fontWeight: '800', color: COLORS.text, marginBottom: SPACING.sm },
  demandeCard: {
    flexDirection: 'row', alignItems: 'center', gap: SPACING.sm,
    backgroundColor: COLORS.card, borderRadius: RADIUS.md,
    padding: SPACING.md, marginBottom: SPACING.sm, ...SHADOW.sm,
  },
  demandeName: { fontSize: FONTS.sm, fontWeight: '700', color: COLORS.text },
  demandeRoute: { fontSize: FONTS.xs, color: COLORS.textLight, marginTop: 2 },
  pendingBadge: {
    backgroundColor: '#FEF3C7', paddingHorizontal: SPACING.sm,
    paddingVertical: 3, borderRadius: RADIUS.full,
  },
  pendingText: { fontSize: FONTS.xs, fontWeight: '700', color: COLORS.warning },
});
