import React, { useState, useEffect } from 'react';
import {
  View, Text, ScrollView, StyleSheet,
  TouchableOpacity, RefreshControl, ActivityIndicator,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../context/AuthContext';
import { getMesDemandes } from '../api/client';
import { COLORS, FONTS, SPACING, RADIUS, SHADOW } from '../utils/theme';

const STATUS_CONFIG = {
  en_attente: { label: 'En attente', color: COLORS.warning, bg: '#FEF3C7', icon: 'time-outline' },
  acceptee:   { label: 'Acceptée',   color: COLORS.success, bg: '#DCFCE7', icon: 'checkmark-circle-outline' },
  refusee:    { label: 'Refusée',    color: COLORS.error,   bg: '#FEE2E2', icon: 'close-circle-outline' },
};

export default function PassagerHomeScreen({ navigation }) {
  const { user } = useAuth();
  const [demandes, setDemandes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const now = new Date();
  const timeStr = now.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });
  const dateStr = now.toLocaleDateString('fr-FR', { weekday: 'long', day: 'numeric', month: 'long' });

  const fetchDemandes = async () => {
    try {
      const data = await getMesDemandes();
      setDemandes(data);
    } catch (e) {
      console.log('Erreur demandes:', e.message);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => { fetchDemandes(); }, []);

  const onRefresh = () => { setRefreshing(true); fetchDemandes(); };

  const latestDemande = demandes[0] || null;

  return (
    <ScrollView
      style={styles.container}
      showsVerticalScrollIndicator={false}
      refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={COLORS.primary} />}
    >
      {/* Top header */}
      <LinearGradient
        colors={[COLORS.primaryDark, COLORS.primary, '#2D6A4F']}
        style={styles.header}
        start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}
      >
        <View style={styles.headerDecor1} />
        <View style={styles.headerDecor2} />

        <View style={styles.headerTop}>
          <View>
            <Text style={styles.greeting}>Bonjour 👋</Text>
            <Text style={styles.userName}>{user?.nom || 'Voyageur'}</Text>
          </View>
          <TouchableOpacity
            style={styles.profileBtn}
            onPress={() => navigation.navigate('Profile')}
          >
            <Ionicons name="person-circle" size={40} color={COLORS.accentLight} />
          </TouchableOpacity>
        </View>

        {/* Date & Météo widgets */}
        <View style={styles.widgetRow}>
          {/* Météo widget */}
          <View style={styles.widget}>
            <Ionicons name="partly-sunny" size={24} color={COLORS.accent} />
            <Text style={styles.widgetValue}>24°C</Text>
            <Text style={styles.widgetLabel}>Antananarivo</Text>
          </View>

          {/* Date & heure */}
          <View style={styles.widget}>
            <Ionicons name="calendar-outline" size={22} color={COLORS.primaryLight} />
            <Text style={styles.widgetValue}>{timeStr}</Text>
            <Text style={styles.widgetLabel}>{dateStr}</Text>
          </View>
        </View>
      </LinearGradient>

      <View style={styles.content}>
        {/* Last trip card */}
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>Dernier trajet</Text>
          <TouchableOpacity onPress={() => navigation.navigate('MesDemandes')}>
            <Text style={styles.seeAll}>Voir tout →</Text>
          </TouchableOpacity>
        </View>

        {loading ? (
          <ActivityIndicator color={COLORS.primary} style={{ marginTop: SPACING.lg }} />
        ) : latestDemande ? (
          <TrajetCard demande={latestDemande} onPress={() => navigation.navigate('Trajet', { demande: latestDemande })} />
        ) : (
          <EmptyCard onPress={() => navigation.navigate('Reservation')} />
        )}

        {/* Quick Actions */}
        <Text style={[styles.sectionTitle, { marginTop: SPACING.lg }]}>Actions rapides</Text>
        <View style={styles.actionsGrid}>
          <QuickAction
            icon="map-outline"
            label="Réserver un trajet"
            color={COLORS.primary}
            onPress={() => navigation.navigate('Reservation')}
          />
          <QuickAction
            icon="list-outline"
            label="Mes demandes"
            color={COLORS.accent}
            onPress={() => navigation.navigate('MesDemandes')}
          />
          <QuickAction
            icon="navigate-outline"
            label="Suivi en direct"
            color='#7C3AED'
            onPress={() => navigation.navigate('Trajet', { demande: latestDemande })}
          />
          <QuickAction
            icon="person-outline"
            label="Mon profil"
            color='#0891B2'
            onPress={() => navigation.navigate('Profile')}
          />
        </View>

        {/* Stats */}
        <Text style={[styles.sectionTitle, { marginTop: SPACING.lg }]}>Mes statistiques</Text>
        <View style={styles.statsRow}>
          <StatCard label="Demandes" value={demandes.length} icon="layers-outline" color={COLORS.primary} />
          <StatCard
            label="Acceptées"
            value={demandes.filter(d => d.statut === 'acceptee').length}
            icon="checkmark-circle-outline"
            color={COLORS.success}
          />
          <StatCard
            label="En attente"
            value={demandes.filter(d => d.statut === 'en_attente').length}
            icon="time-outline"
            color={COLORS.warning}
          />
        </View>
      </View>
    </ScrollView>
  );
}

const TrajetCard = ({ demande, onPress }) => {
  const cfg = STATUS_CONFIG[demande.statut] || STATUS_CONFIG.en_attente;
  return (
    <TouchableOpacity style={styles.trajetCard} onPress={onPress} activeOpacity={0.85}>
      <View style={styles.trajetRoute}>
        <View style={styles.routePoint}>
          <View style={[styles.dot, { backgroundColor: COLORS.primary }]} />
          <Text style={styles.routeCity}>{demande.ville_depart}</Text>
        </View>
        <View style={styles.routeLine}>
          <Ionicons name="arrow-forward" size={16} color={COLORS.textLight} />
        </View>
        <View style={styles.routePoint}>
          <View style={[styles.dot, { backgroundColor: COLORS.accent }]} />
          <Text style={styles.routeCity}>{demande.ville_arrivee}</Text>
        </View>
      </View>
      <View style={[styles.statusBadge, { backgroundColor: cfg.bg }]}>
        <Ionicons name={cfg.icon} size={13} color={cfg.color} />
        <Text style={[styles.statusText, { color: cfg.color }]}>{cfg.label}</Text>
      </View>
    </TouchableOpacity>
  );
};

const EmptyCard = ({ onPress }) => (
  <TouchableOpacity style={styles.emptyCard} onPress={onPress} activeOpacity={0.85}>
    <Ionicons name="add-circle-outline" size={40} color={COLORS.primaryLight} />
    <Text style={styles.emptyTitle}>Aucun trajet</Text>
    <Text style={styles.emptyDesc}>Appuyez pour réserver votre premier trajet</Text>
  </TouchableOpacity>
);

const QuickAction = ({ icon, label, color, onPress }) => (
  <TouchableOpacity style={styles.quickAction} onPress={onPress} activeOpacity={0.8}>
    <View style={[styles.quickActionIcon, { backgroundColor: `${color}18` }]}>
      <Ionicons name={icon} size={24} color={color} />
    </View>
    <Text style={styles.quickActionLabel}>{label}</Text>
  </TouchableOpacity>
);

const StatCard = ({ label, value, icon, color }) => (
  <View style={styles.statCard}>
    <Ionicons name={icon} size={20} color={color} />
    <Text style={[styles.statValue, { color }]}>{value}</Text>
    <Text style={styles.statLabel}>{label}</Text>
  </View>
);

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.background },

  header: {
    paddingTop: 55, paddingHorizontal: SPACING.lg,
    paddingBottom: SPACING.xl, overflow: 'hidden',
  },
  headerDecor1: {
    position: 'absolute', top: -40, right: -20,
    width: 160, height: 160, borderRadius: 80,
    backgroundColor: 'rgba(249,115,22,0.1)',
  },
  headerDecor2: {
    position: 'absolute', bottom: -20, left: -30,
    width: 100, height: 100, borderRadius: 50,
    backgroundColor: 'rgba(82,183,136,0.15)',
  },

  headerTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: SPACING.lg },
  greeting: { fontSize: FONTS.md, color: 'rgba(255,255,255,0.75)' },
  userName: { fontSize: FONTS.xxl, fontWeight: '800', color: '#fff', marginTop: 2 },
  profileBtn: {},

  widgetRow: { flexDirection: 'row', gap: SPACING.md },
  widget: {
    flex: 1, backgroundColor: 'rgba(255,255,255,0.12)',
    borderRadius: RADIUS.md, padding: SPACING.md,
    borderWidth: 1, borderColor: 'rgba(255,255,255,0.15)',
    alignItems: 'flex-start', gap: 4,
  },
  widgetValue: { fontSize: FONTS.xl, fontWeight: '800', color: '#fff', marginTop: 4 },
  widgetLabel: { fontSize: FONTS.xs, color: 'rgba(255,255,255,0.65)', textTransform: 'capitalize' },

  content: { padding: SPACING.lg },

  sectionHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: SPACING.sm },
  sectionTitle: { fontSize: FONTS.lg, fontWeight: '800', color: COLORS.text },
  seeAll: { fontSize: FONTS.sm, color: COLORS.primary, fontWeight: '600' },

  trajetCard: {
    backgroundColor: COLORS.card, borderRadius: RADIUS.lg,
    padding: SPACING.md, ...SHADOW.md,
    flexDirection: 'row', alignItems: 'center',
    justifyContent: 'space-between',
  },
  trajetRoute: { flexDirection: 'row', alignItems: 'center', gap: SPACING.sm, flex: 1 },
  routePoint: { alignItems: 'center', gap: 4 },
  dot: { width: 10, height: 10, borderRadius: 5 },
  routeCity: { fontSize: FONTS.sm, fontWeight: '700', color: COLORS.text },
  routeLine: { flex: 1, alignItems: 'center' },
  statusBadge: {
    flexDirection: 'row', alignItems: 'center', gap: 4,
    paddingHorizontal: SPACING.sm, paddingVertical: SPACING.xs,
    borderRadius: RADIUS.full,
  },
  statusText: { fontSize: FONTS.xs, fontWeight: '700' },

  emptyCard: {
    backgroundColor: COLORS.card, borderRadius: RADIUS.lg,
    padding: SPACING.xl, alignItems: 'center',
    ...SHADOW.sm, borderWidth: 2, borderStyle: 'dashed',
    borderColor: COLORS.border,
  },
  emptyTitle: { fontSize: FONTS.lg, fontWeight: '700', color: COLORS.text, marginTop: SPACING.sm },
  emptyDesc: { fontSize: FONTS.sm, color: COLORS.textLight, textAlign: 'center', marginTop: 4 },

  actionsGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: SPACING.sm, marginTop: SPACING.sm },
  quickAction: {
    width: '47%', backgroundColor: COLORS.card,
    borderRadius: RADIUS.lg, padding: SPACING.md,
    alignItems: 'center', gap: SPACING.sm, ...SHADOW.sm,
  },
  quickActionIcon: {
    width: 52, height: 52, borderRadius: RADIUS.md,
    justifyContent: 'center', alignItems: 'center',
  },
  quickActionLabel: { fontSize: FONTS.sm, fontWeight: '700', color: COLORS.text, textAlign: 'center' },

  statsRow: { flexDirection: 'row', gap: SPACING.sm, marginTop: SPACING.sm, marginBottom: SPACING.xl },
  statCard: {
    flex: 1, backgroundColor: COLORS.card,
    borderRadius: RADIUS.lg, padding: SPACING.md,
    alignItems: 'center', gap: 4, ...SHADOW.sm,
  },
  statValue: { fontSize: FONTS.xxl, fontWeight: '800' },
  statLabel: { fontSize: FONTS.xs, color: COLORS.textLight, fontWeight: '600' },
});
