import React, { useState } from 'react';
import {
  View, Text, TextInput, TouchableOpacity,
  StyleSheet, KeyboardAvoidingView, Platform,
  ActivityIndicator, Alert, ScrollView,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../context/AuthContext';
import { login } from '../api/client';
import { COLORS, FONTS, SPACING, RADIUS, SHADOW } from '../utils/theme';

export default function LoginScreen({ navigation }) {
  const { signIn } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleLogin = async () => {
    if (!email.trim() || !password.trim()) {
      Alert.alert('Champs manquants', 'Veuillez remplir tous les champs.');
      return;
    }
    setLoading(true);
    try {
      const data = await login(email.trim(), password);
      await signIn(data.user, data.token);
    } catch (err) {
      Alert.alert('Connexion échouée', err.message || 'Identifiants incorrects.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
    >
      <LinearGradient
        colors={[COLORS.primaryDark, COLORS.primary, '#2D6A4F']}
        style={styles.topSection}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
      >
        {/* Decorative circles */}
        <View style={styles.circleTopRight} />
        <View style={styles.circleBottomLeft} />

        <View style={styles.logoArea}>
          <View style={styles.logoIcon}>
            <Ionicons name="bus" size={36} color={COLORS.accent} />
          </View>
          <Text style={styles.appName}>SmartTransport</Text>
          <Text style={styles.tagline}>Voyagez intelligent à Madagascar</Text>
        </View>
      </LinearGradient>

      <ScrollView
        style={styles.formContainer}
        contentContainerStyle={styles.formContent}
        keyboardShouldPersistTaps="handled"
      >
        <Text style={styles.title}>Connexion</Text>
        <Text style={styles.subtitle}>Saisissez vos informations pour continuer</Text>

        {/* Email */}
        <View style={styles.inputWrapper}>
          <Text style={styles.label}>Adresse e-mail</Text>
          <View style={styles.inputContainer}>
            <Ionicons name="mail-outline" size={18} color={COLORS.textLight} style={styles.inputIcon} />
            <TextInput
              style={styles.input}
              placeholder="exemple@mail.com"
              placeholderTextColor={COLORS.textLight}
              value={email}
              onChangeText={setEmail}
              keyboardType="email-address"
              autoCapitalize="none"
              autoComplete="email"
            />
          </View>
        </View>

        {/* Password */}
        <View style={styles.inputWrapper}>
          <Text style={styles.label}>Mot de passe</Text>
          <View style={styles.inputContainer}>
            <Ionicons name="lock-closed-outline" size={18} color={COLORS.textLight} style={styles.inputIcon} />
            <TextInput
              style={[styles.input, styles.inputFlex]}
              placeholder="••••••••"
              placeholderTextColor={COLORS.textLight}
              value={password}
              onChangeText={setPassword}
              secureTextEntry={!showPassword}
            />
            <TouchableOpacity onPress={() => setShowPassword(!showPassword)} style={styles.eyeBtn}>
              <Ionicons
                name={showPassword ? 'eye-off-outline' : 'eye-outline'}
                size={18}
                color={COLORS.textLight}
              />
            </TouchableOpacity>
          </View>
        </View>

        {/* Login Button */}
        <TouchableOpacity
          style={styles.loginBtn}
          onPress={handleLogin}
          disabled={loading}
          activeOpacity={0.85}
        >
          <LinearGradient
            colors={[COLORS.accent, '#EA580C']}
            style={styles.loginBtnGradient}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 0 }}
          >
            {loading ? (
              <ActivityIndicator color="#fff" />
            ) : (
              <>
                <Text style={styles.loginBtnText}>Se connecter</Text>
                <Ionicons name="arrow-forward" size={18} color="#fff" />
              </>
            )}
          </LinearGradient>
        </TouchableOpacity>

        {/* Register link */}
        <View style={styles.registerRow}>
          <Text style={styles.registerText}>Pas encore de compte ? </Text>
          <TouchableOpacity onPress={() => navigation.navigate('Register')}>
            <Text style={styles.registerLink}>Créer un compte</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.background },

  topSection: {
    height: 260,
    justifyContent: 'flex-end',
    paddingBottom: SPACING.xl,
    overflow: 'hidden',
  },
  circleTopRight: {
    position: 'absolute', top: -40, right: -40,
    width: 160, height: 160, borderRadius: 80,
    backgroundColor: 'rgba(249,115,22,0.15)',
  },
  circleBottomLeft: {
    position: 'absolute', bottom: -30, left: -20,
    width: 120, height: 120, borderRadius: 60,
    backgroundColor: 'rgba(82,183,136,0.2)',
  },

  logoArea: { alignItems: 'center', paddingHorizontal: SPACING.lg },
  logoIcon: {
    width: 72, height: 72, borderRadius: 20,
    backgroundColor: 'rgba(249,115,22,0.15)',
    justifyContent: 'center', alignItems: 'center',
    marginBottom: SPACING.sm,
    borderWidth: 1.5,
    borderColor: 'rgba(249,115,22,0.3)',
  },
  appName: {
    fontSize: FONTS.xxl, fontWeight: '800',
    color: '#fff', letterSpacing: 0.5,
  },
  tagline: {
    fontSize: FONTS.sm, color: 'rgba(255,255,255,0.7)',
    marginTop: 4, letterSpacing: 0.3,
  },

  formContainer: { flex: 1 },
  formContent: {
    padding: SPACING.lg, paddingTop: SPACING.xl,
  },

  title: {
    fontSize: FONTS.xxl, fontWeight: '800',
    color: COLORS.text, marginBottom: 4,
  },
  subtitle: {
    fontSize: FONTS.sm, color: COLORS.textLight,
    marginBottom: SPACING.xl,
  },

  inputWrapper: { marginBottom: SPACING.md },
  label: {
    fontSize: FONTS.sm, fontWeight: '600',
    color: COLORS.text, marginBottom: SPACING.xs,
    letterSpacing: 0.2,
  },
  inputContainer: {
    flexDirection: 'row', alignItems: 'center',
    backgroundColor: COLORS.card,
    borderRadius: RADIUS.md,
    borderWidth: 1.5, borderColor: COLORS.border,
    paddingHorizontal: SPACING.md,
    height: 52,
    ...SHADOW.sm,
  },
  inputIcon: { marginRight: SPACING.sm },
  input: {
    flex: 1, fontSize: FONTS.md,
    color: COLORS.text, height: '100%',
  },
  inputFlex: { flex: 1 },
  eyeBtn: { padding: SPACING.xs },

  loginBtn: {
    marginTop: SPACING.md, borderRadius: RADIUS.md, overflow: 'hidden',
    ...SHADOW.md,
  },
  loginBtnGradient: {
    height: 54, flexDirection: 'row',
    alignItems: 'center', justifyContent: 'center', gap: 8,
  },
  loginBtnText: {
    fontSize: FONTS.md, fontWeight: '700',
    color: '#fff', letterSpacing: 0.3,
  },

  registerRow: {
    flexDirection: 'row', justifyContent: 'center',
    marginTop: SPACING.lg, alignItems: 'center',
  },
  registerText: { fontSize: FONTS.sm, color: COLORS.textLight },
  registerLink: {
    fontSize: FONTS.sm, fontWeight: '700',
    color: COLORS.primary, textDecorationLine: 'underline',
  },
});
