const express = require('express');
const cors = require('cors');
require('dotenv').config();
const pool = require('./db');

// Import des routes
const authRoutes = require('./routes/auth');
const villesRoutes = require('./routes/villes');
const routesRoutes = require('./routes/routes');
const itineraryRoutes = require('./routes/itinerary');
const demandesRoutes = require('./routes/demandes');
const reservationsRoutes = require('./routes/reservations');
const vehiclesRoutes = require('./routes/vehicles');
const planningsRoutes = require('./routes/plannings');
const trafficRoutes = require('./routes/traffic');
const logsRoutes = require('./routes/logs');

const app = express();
const PORT = process.env.PORT || 5000;

// ── Middleware ────────────────────────────────────────────────
// Autorise toutes les origines (nécessaire pour Expo Go)
app.use(cors({
  origin: '*',
  methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization'],
}));
app.use(express.json());

// ── Routes ────────────────────────────────────────────────────
app.use('/api/auth', authRoutes);
app.use('/api/villes', villesRoutes);
app.use('/api/routes', routesRoutes);
app.use('/api/itinerary', itineraryRoutes);
app.use('/api/demandes', demandesRoutes);
app.use('/api/reservations', reservationsRoutes);
app.use('/api/vehicules', vehiclesRoutes);
app.use('/api/plannings', planningsRoutes);
app.use('/api/traffic', trafficRoutes);
app.use('/api/logs', logsRoutes);

// Route de test (utile pour vérifier la connexion depuis le téléphone)
app.get('/api/ping', (req, res) => {
  res.json({ message: 'SmartTransport 2035 API is running', timestamp: new Date().toISOString() });
});

// ── Connexion MySQL ───────────────────────────────────────────
async function testDbConnection() {
  try {
    const connection = await pool.getConnection();
    console.log('✅ Connexion à MySQL réussie.');
    connection.release();
    return true;
  } catch (error) {
    console.error('❌ Échec de connexion à MySQL :', error.message);
    return false;
  }
}

// ── Démarrage ─────────────────────────────────────────────────
// '0.0.0.0' = écoute sur toutes les interfaces réseau
// (obligatoire pour être accessible depuis le téléphone)
testDbConnection().then((isConnected) => {
  if (isConnected) {
    app.listen(PORT, '0.0.0.0', () => {
      console.log(`✅ Serveur démarré sur le port ${PORT}`);
      console.log(`   → Accès local  : http://localhost:${PORT}`);
      console.log(`   → Depuis tél.  : http://<votre-ip-locale>:${PORT}`);
      console.log(`   → Test rapide  : http://localhost:${PORT}/api/ping`);
    });
  } else {
    console.error('❌ Le serveur ne peut pas démarrer : base de données inaccessible.');
    process.exit(1);
  }
});
