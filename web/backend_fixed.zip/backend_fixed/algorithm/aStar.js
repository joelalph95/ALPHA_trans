const { haversine } = require('../utils/helpers');

function aStarOptimized(graph, startId, goalId, cityCoords) {

  // Si départ = arrivée
  if (startId == goalId) {
    return {
      path: [parseInt(startId)],
      distance_km: 0,
      temps_minutes: 0,
      temps_heures: 0,
      temps_minutes_restantes: 0,
      cout_Ar: 0
    };
  }

  function getVitesse(etat, trafic) {
    let vitesseBase;
    switch (etat) {
      case 'ouverte':   vitesseBase = 60; break;
      case 'degradee':  vitesseBase = 40; break;
      case 'mauvaise':  vitesseBase = 30; break;
      default:          vitesseBase = 40;
    }
    const coeffTrafic = [0, 1.0, 0.8, 0.6, 0.4, 0.2];
    const facteur = coeffTrafic[trafic] || 0.8;
    return vitesseBase * facteur;
  }

  function calculerTemps(distance, etat, trafic) {
    const vitesse = getVitesse(etat, trafic);
    if (vitesse <= 0) return Infinity;
    return (distance / vitesse) * 60;
  }

  function heuristiqueTemps(lat1, lon1, lat2, lon2) {
    const distanceKm = haversine(lat1, lon1, lat2, lon2);
    const VITESSE_HEURISTIQUE = 50;
    return (distanceKm / VITESSE_HEURISTIQUE) * 60;
  }

  const openSet = new Set([startId]);
  const cameFrom = {};
  const gScore = {};
  const fScore = {};

  for (const nodeId of Object.keys(graph)) {
    gScore[nodeId] = Infinity;
    fScore[nodeId] = Infinity;
  }

  gScore[startId] = 0;
  fScore[startId] = heuristiqueTemps(
    cityCoords[startId].lat, cityCoords[startId].lon,
    cityCoords[goalId].lat, cityCoords[goalId].lon
  );

  while (openSet.size > 0) {
    let current = null;
    let minF = Infinity;
    for (const id of openSet) {
      if (fScore[id] < minF) {
        minF = fScore[id];
        current = id;
      }
    }

    if (current == goalId) {
      const path = [];
      let tmp = goalId;
      while (tmp !== undefined) {
        path.unshift(parseInt(tmp));
        tmp = cameFrom[tmp];
      }

      let distanceTotale = 0;
      for (let i = 0; i < path.length - 1; i++) {
        const from = path[i];
        const to = path[i + 1];
        const edge = (graph[from] || []).find(e => e.id == to);
        if (edge) distanceTotale += edge.distance;
      }

      return {
        path: path,
        distance_km: Math.round(distanceTotale * 100) / 100,
        temps_minutes: Math.round(gScore[goalId]),
        temps_heures: Math.floor(gScore[goalId] / 60),
        temps_minutes_restantes: Math.round(gScore[goalId] % 60),
        cout_Ar: Math.round(distanceTotale * 300)
      };
    }

    openSet.delete(current);

    for (const neighbor of graph[current] || []) {
      const tempsRoute = calculerTemps(neighbor.distance, neighbor.etat, neighbor.trafic);
      if (tempsRoute === Infinity) continue;

      const tentativeG = gScore[current] + tempsRoute;

      if (tentativeG < gScore[neighbor.id]) {
        cameFrom[neighbor.id] = current;
        gScore[neighbor.id] = tentativeG;
        fScore[neighbor.id] = tentativeG + heuristiqueTemps(
          cityCoords[neighbor.id].lat, cityCoords[neighbor.id].lon,
          cityCoords[goalId].lat, cityCoords[goalId].lon
        );
        openSet.add(neighbor.id);
      }
    }
  }

  return null;
}

module.exports = aStarOptimized;